SELECT 	*
FROM 	Book
ORDER BY 	price DESC, publisher ASC;