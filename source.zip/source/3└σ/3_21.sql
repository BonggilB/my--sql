SELECT	*
FROM	Customer, Orders
WHERE	Customer.custid=Orders.custid;