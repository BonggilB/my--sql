DELETE	FROM	Customer;


