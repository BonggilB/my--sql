DROP VIEW	vw_Customer;

SELECT	*
FROM	vw_Customer;
