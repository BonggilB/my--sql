DROP INDEX ix_Book ON Book;
