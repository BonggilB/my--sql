use madang;
select * from madang.book;