REVOKE SELECT ON madang.Customer FROM mdguest@localhost;
