SELECT	*
FROM	Book
WHERE	publisher ='굿스포츠' OR publisher ='대한미디어';