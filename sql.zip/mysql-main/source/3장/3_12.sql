SELECT	*
FROM	Book
ORDER BY	bookname;