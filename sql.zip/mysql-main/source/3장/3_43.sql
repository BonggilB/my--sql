DROP TABLE NewCustomer;
select * from NewCustomer;

DROP TABLE NewOrders;
DROP TABLE NewCustomer;

select * from newbook;
select * from NewCustomer;
select * from neworders;