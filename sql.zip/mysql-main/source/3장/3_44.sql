INSERT INTO Book(bookid, bookname, publisher, price)
	    VALUES (11, '스포츠 의학', '한솔의학서적', 90000);
        
select  * from book;        