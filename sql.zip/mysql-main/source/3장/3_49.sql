DELETE FROM Book 
WHERE  bookid = '11'; 

select * from book;