SELECT	*
FROM	Book
WHERE	bookname LIKE '_구%';