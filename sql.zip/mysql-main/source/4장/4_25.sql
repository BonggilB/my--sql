CREATE INDEX ix_Book2 ON Book(publisher, price);

show index from book;

