CREATE TABLE Book_log(
  bookid_l INTEGER,
  bookname_l VARCHAR(40),
  publisher_l VARCHAR(40),
  price_l INTEGER);