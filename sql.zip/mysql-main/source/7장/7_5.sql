/* 자바 강좌 삽입, NULL 값을 입력할 필요 없음 */
INSERT INTO SummerPrice VALUES ('JAVA', 25000);

SELECT	*
FROM	SummerPrice;

/* 수강신청 정보 확인 */
SELECT	*
FROM	SummerEnroll;