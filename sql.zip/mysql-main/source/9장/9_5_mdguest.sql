Use madang;
SELECT * FROM Book;

