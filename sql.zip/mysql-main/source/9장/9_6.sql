GRANT SELECT, UPDATE ON madang.Customer TO mdguest@localhost 
	WITH GRANT OPTION;