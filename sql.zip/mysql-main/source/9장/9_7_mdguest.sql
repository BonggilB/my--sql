GRANT SELECT ON madang.Book TO mdguest2;

GRANT SELECT ON madang.Customer TO mdguest2;