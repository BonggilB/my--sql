SELECT * FROM book;
/*
	11,'홍길동전','연희출판사',20000을  
	book테이블의 bookid,bookname,publisher,price에 삽입
*/
-- INSERT INTO book(bookid,bookname,publisher,price) 
-- VALUES(11,'홍길동전','연희출판사',20000);

-- INSERT INTO book 
-- VALUES(12,'성춘향전','연희출판사',18000);

-- INSERT INTO book(bookname,bookid,price,publisher)
-- VALUES('강감찬전',13,16000,'거기출판사');

-- INSERT INTO book
-- VALUES(14,'을지문덕전',NULL,NULL);

SELECT * FROM book;








