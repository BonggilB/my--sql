/*
을지문덕적의 publisher와 price를 '대한미디어',16500로 업데이트 하시오
*/
-- UPDATE book
-- SET publisher='대한미디어',price=16500
-- WHERE bookname='을지문덕전';

SELECT * FROM book;