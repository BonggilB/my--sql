SELECT * FROM book;

DELETE FROM book
WHERE publisher='대한미디어';

SELECT * FROM book;